<html>
    <body style="background-color:#000000">
        
        <center><img src="<?php echo e(asset('admin/assets/images/login-logo.png')); ?>" alt=""></center>
    </body>
</html><?php /**PATH C:\xampp\htdocs\ride_hailing\resources\views/welcome.blade.php ENDPATH**/ ?>