<!DOCTYPE html>
<html lang="en">
	<head>
		<?php echo $__env->make('admin.common.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</head>
	<body class="">
		<section id="wrapper" class="wrapper">
			<?php echo $__env->make('admin.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<section class="content-area">
				<?php echo $__env->make('admin.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php echo $__env->yieldContent('content'); ?>
			</section>
			<?php echo $__env->make('admin.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</section>
		<?php echo $__env->make('admin.common.footer-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</body>

</html>

<?php /**PATH C:\xampp\htdocs\ride_hailing\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>