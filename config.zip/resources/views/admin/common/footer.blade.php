<section id="footer" class="footer py-4">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<p class="copyright m-0">all rights reserved by ECEETECH Softwares</p>
			</div>
		</div>
	</div>
</section>