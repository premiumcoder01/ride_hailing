<html>
    <body style="background-color:#000000">
        
        <center><img src="{{asset('admin/assets/images/login-logo.png')}}" alt=""></center>
    </body>
</html>